//
//  ViewController.m
//  NSUserDefaults读取和保存应用程序参数
//
//  Created by apple on 2016/12/1.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextField *nameText;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UITextField *bgmusic;
@property (weak, nonatomic) IBOutlet UITextField *speed;
@property (weak, nonatomic) IBOutlet UITextField *race;
- (IBAction)save:(id)sender;
- (IBAction)revise:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //让每个UITextfield变为不可编辑状态
    _nameText.userInteractionEnabled = NO;
    _password.userInteractionEnabled = NO;
    _bgmusic.userInteractionEnabled = NO;
    _speed.userInteractionEnabled = NO;
    _race.userInteractionEnabled = NO;


    //获取该应用UIApplication对象
    UIApplication *app=[UIApplication sharedApplication];
    
    //注册让self监视app发出的UIApplicationWillEnterForegroundNotification通知
    //该通知发生时，激活appWillEnterFore
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(appWillEnterFore:) name:UIApplicationWillEnterForegroundNotification object:app];
}

-(void)refreshFileds{
    //获取该应用的NSUserDefaults
    NSUserDefaults* defaults=[NSUserDefaults standardUserDefaults];
    //获取NSUserDefaults中保存的值来更新界面上的UI控件值
    self.nameText.text=[defaults stringForKey:@"name"];
    self.password.text=[defaults stringForKey:@"password"];
    self.bgmusic.text=[defaults stringForKey:@"bgmusic"];
    self.speed.text=[defaults stringForKey:@"speed"];
    self.race.text=[defaults stringForKey:@"race"];
}




//当该视图控制器显示时会自动调用该方法
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //使用NSUserDefault中的参数更新界面上的UI控件的值
    [self refreshFileds];
}

//接收到通知时激发该方法
-(void) appWillEnterFore:(NSNotification*) notification{
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    //保存所有修改
    [defaults synchronize];
    //使用NSUserDefaults中的参数更新界面上的UI控件的值
    [self refreshFileds];
    
}


- (IBAction)save:(id)sender {
    //让每个UITextfield变为不可编辑状态
    _nameText.userInteractionEnabled = NO;
    _password.userInteractionEnabled = NO;
    _bgmusic.userInteractionEnabled = NO;
    _speed.userInteractionEnabled = NO;
    _race.userInteractionEnabled = NO;

    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    //将nameText控件值设置到NSUserDefaults中
    [defaults setValue:_nameText.text forKey:@"name"];
    [defaults setValue:_password.text forKey:@"password"];
    [defaults setValue:_bgmusic.text forKey:@"bgmusic"];
    [defaults setValue:_speed.text forKey:@"speed"];
    [defaults setValue:_race.text forKey:@"race"];
    //保存修改
    [defaults synchronize];
}

- (IBAction)revise:(id)sender {
     //让每个UITextfield变为可编辑状态
    _nameText.userInteractionEnabled = YES;
    _password.userInteractionEnabled = YES;
    _bgmusic.userInteractionEnabled = YES;
    _speed.userInteractionEnabled = YES;
    _race.userInteractionEnabled = YES;
//    NSLog(@"%@", self.nameText.userInteractionEnabled ? @"YES" : @"NO");

}

//点击背景回收键盘
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    UIView *view = (UIView *)[touch view];
    if (view ==self.view) {
        [self.nameText resignFirstResponder];
        [self.password resignFirstResponder];
        [self.bgmusic resignFirstResponder];
        [self.speed resignFirstResponder];
        [self.race resignFirstResponder];
    }
}
@end
